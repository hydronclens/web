import React, { useState } from 'react';
import {
  ArrowRight, ArrowUpRight, Menu, X, CheckCircle2, Factory, FlaskConical,
  ShieldCheck, Globe2, PackageCheck, Microscope, Handshake, ChevronDown,
  Mail, MapPin, Phone, Send, CircleHelp, BadgeCheck, Boxes, Eye, Sparkles
} from 'lucide-react';

const products = [
  {
    id: 'clear',
    name: 'Clear Contact Lenses',
    eyebrow: 'OPTICAL CLARITY',
    description: 'A range of clear soft contact lens options for different replacement schedules and market requirements.',
    image: 'https://images.unsplash.com/photo-1574258495973-f010dfbb5371?auto=format&fit=crop&w=1000&q=85',
    tag: 'Clear lens portfolio'
  },
  {
    id: 'color',
    name: 'Colored Contact Lenses',
    eyebrow: 'COLOR & DESIGN',
    description: 'Explore colored lens collections, design options, and opportunities for brand-specific assortments.',
    image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=1000&q=85',
    tag: 'Color collections'
  },
  {
    id: 'care',
    name: 'Lens-Care Solutions',
    eyebrow: 'EVERYDAY CARE',
    description: 'Multipurpose contact lens solution and related eye-care products for suitable markets and channels.',
    image: 'https://images.unsplash.com/photo-1607619056574-7b8d3ee536b2?auto=format&fit=crop&w=1000&q=85',
    tag: 'MPS & eye care'
  }
];

const capabilities = [
  { icon: Factory, title: 'Manufacturing experience', text: 'A manufacturing-led approach built around product consistency, process discipline, and long-term partnerships.' },
  { icon: FlaskConical, title: 'Product development', text: 'Discuss product formats, lens specifications, packaging options, and market-specific requirements with our team.' },
  { icon: ShieldCheck, title: 'Quality & documentation', text: 'Request information about applicable quality systems, product documentation, and available certificates.' },
  { icon: Globe2, title: 'International cooperation', text: 'Work with a team experienced in supporting overseas customers, distributors, and private-label projects.' }
];

const steps = [
  ['01', 'Share your requirements', 'Tell us your target market, product interests, estimated quantities, and brand plans.'],
  ['02', 'Review product options', 'Discuss available specifications, packaging formats, samples, and project feasibility.'],
  ['03', 'Confirm the proposal', 'Review quotation, MOQ, artwork, applicable documents, and commercial terms.'],
  ['04', 'Plan production & shipment', 'Align on approved specifications, production planning, and shipping arrangements.']
];

function Logo() {
  return <a className="brand" href="#home" aria-label="Haichang home">
    <span className="brand-mark"><Eye size={25} strokeWidth={1.8} /></span>
    <span className="brand-copy"><strong>HAICHANG</strong><small>CONTACT LENS MANUFACTURING</small></span>
  </a>;
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: '', company: '', email: '', country: '', product: 'OEM / Private Label', quantity: '', message: '' });
  const [activeFaq, setActiveFaq] = useState(0);

  const navItems = [
    ['About', '#about'], ['Products', '#products'], ['OEM & Private Label', '#oem'],
    ['Quality', '#quality'], ['Horien', '#horien'], ['Contact', '#contact']
  ];
  const update = (e) => setForm({ ...form, [e.target.name]: e.target.value });
  const submitForm = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return <div id="home">
    <div className="topline">
      <div className="container topline-inner">
        <span><Globe2 size={14} /> International manufacturing & brand partnerships</span>
        <span className="topline-right">Danyang, Jiangsu, China <span className="dot">•</span> Global B2B inquiries</span>
      </div>
    </div>
    <header className="header">
      <div className="container nav-wrap">
        <Logo />
        <button className="mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation">{menuOpen ? <X /> : <Menu />}</button>
        <nav className={menuOpen ? 'nav nav-open' : 'nav'}>
          {navItems.map(([label, href]) => <a key={label} href={href} onClick={() => setMenuOpen(false)}>{label}</a>)}
          <a className="nav-cta" href="#contact" onClick={() => setMenuOpen(false)}>Request a quote <ArrowUpRight size={16} /></a>
        </nav>
      </div>
    </header>

    <main>
      <section className="hero">
        <div className="hero-image" />
        <div className="hero-shade" />
        <div className="container hero-content">
          <div className="eyebrow light"><span /> YOUR CONTACT LENS MANUFACTURING PARTNER</div>
          <h1>Precision in every lens.<br /><em>Partnership in every project.</em></h1>
          <p>Contact lens and lens-care product solutions for international brands, distributors, and businesses building their next chapter.</p>
          <div className="hero-actions">
            <a className="button button-primary" href="#products">Explore our products <ArrowRight size={17} /></a>
            <a className="button button-glass" href="#oem">Explore OEM solutions <ArrowRight size={17} /></a>
          </div>
          <div className="hero-footnote"><span className="hero-line" /> A manufacturing-led approach. A global outlook.</div>
        </div>
        <div className="hero-index"><span>01</span><span className="index-line" /><span>04</span></div>
      </section>

      <section className="trust-strip">
        <div className="container trust-grid">
          <div className="trust-intro"><span className="eyebrow">BUILT FOR B2B</span><strong>Helping businesses bring<br />eye-care products to market.</strong></div>
          <div className="trust-item"><Factory /><span><strong>Manufacturing focus</strong><small>Product & production expertise</small></span></div>
          <div className="trust-item"><Boxes /><span><strong>Broad product scope</strong><small>Lenses & lens-care solutions</small></span></div>
          <div className="trust-item"><Handshake /><span><strong>Business partnerships</strong><small>OEM & branded supply</small></span></div>
        </div>
      </section>

      <section className="section intro-section" id="about">
        <div className="container two-col intro-grid">
          <div className="section-heading">
            <div className="eyebrow"><span /> ABOUT HAICHANG</div>
            <h2>A manufacturing partner for a world that sees more.</h2>
            <p className="lead">Haichang brings contact lens manufacturing and international business cooperation together to support customers across product categories and markets.</p>
            <a className="text-link" href="#contact">Start a conversation <ArrowRight size={17} /></a>
          </div>
          <div className="intro-visual">
            <img src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=1200&q=85" alt="Technical team working in a modern production environment" />
            <div className="visual-caption"><span className="caption-icon"><Microscope size={20} /></span><span><strong>Focused on product and process</strong><small>Explore capabilities and cooperation options</small></span></div>
            <div className="floating-seal"><Sparkles size={20} /><span>Built on<br /><strong>experience</strong></span></div>
          </div>
        </div>
      </section>

      <section className="section products-section" id="products">
        <div className="container">
          <div className="section-top">
            <div><div className="eyebrow"><span /> OUR PRODUCT PORTFOLIO</div><h2>Solutions for different needs.<br /><em>One partner to explore them with.</em></h2></div>
            <p>Discover our core product categories and discuss the formats, specifications, and packaging options relevant to your market.</p>
          </div>
          <div className="product-grid">
            {products.map((p, i) => <article className="product-card" key={p.id}>
              <a className="product-image" href="#contact" aria-label={`Ask about ${p.name}`}>
                <img src={p.image} alt={p.name} loading="lazy" />
                <span className="product-number">0{i + 1}</span>
                <span className="image-arrow"><ArrowUpRight size={19} /></span>
              </a>
              <div className="product-body"><span className="eyebrow product-eyebrow">{p.eyebrow}</span><h3>{p.name}</h3><p>{p.description}</p><a className="text-link" href="#contact" onClick={() => setForm({ ...form, product: p.name })}>Discuss this category <ArrowRight size={16} /></a></div>
            </article>)}
          </div>
          <div className="product-note"><CircleHelp size={17} /><span>Product availability, specifications, and packaging depend on the selected product and market. Contact us to confirm details.</span></div>
        </div>
      </section>

      <section className="oem-section" id="oem">
        <div className="oem-photo" />
        <div className="oem-panel">
          <div className="eyebrow light"><span /> OEM & PRIVATE LABEL</div>
          <h2>Build your brand.<br /><em>We’ll discuss the path.</em></h2>
          <p>From product selection to branded packaging, start with a clear conversation about your market, specifications, and business plan.</p>
          <div className="oem-benefits">
            <div><CheckCircle2 /><span><strong>Product selection</strong><small>Discuss suitable product options and formats.</small></span></div>
            <div><CheckCircle2 /><span><strong>Brand & packaging</strong><small>Review available customization possibilities.</small></span></div>
            <div><CheckCircle2 /><span><strong>Market documentation</strong><small>Identify relevant document requirements early.</small></span></div>
          </div>
          <a className="button button-white" href="#contact">Discuss your project <ArrowRight size={17} /></a>
        </div>
      </section>

      <section className="section capabilities-section" id="quality">
        <div className="container">
          <div className="center-heading"><div className="eyebrow"><span /> WHY HAICHANG</div><h2>Built around what matters<br /><em>to your business.</em></h2><p>Strong partnerships begin with clear information, realistic planning, and a shared understanding of product requirements.</p></div>
          <div className="capability-grid">
            {capabilities.map(({ icon: Icon, title, text }, i) => <article className="capability-card" key={title}><div className="capability-icon"><Icon size={23} /></div><span className="capability-index">0{i + 1}</span><h3>{title}</h3><p>{text}</p></article>)}
          </div>
          <div className="quality-banner"><div className="quality-icon"><BadgeCheck size={28} /></div><div><strong>Looking for quality or regulatory documentation?</strong><p>Contact our team to discuss the documents applicable to your product and target market.</p></div><a className="text-link" href="#contact">Make an inquiry <ArrowRight size={16} /></a></div>
        </div>
      </section>

      <section className="section process-section">
        <div className="container process-layout">
          <div className="section-heading"><div className="eyebrow"><span /> HOW WE WORK</div><h2>Clear steps.<br /><em>Better collaboration.</em></h2><p className="lead">Every project starts with understanding your requirements. We work through product fit, feasibility, documentation, and commercial details before order confirmation.</p><a className="text-link" href="#contact">Tell us about your project <ArrowRight size={17} /></a></div>
          <div className="steps-list">{steps.map(([num, title, text]) => <div className="step" key={num}><span className="step-num">{num}</span><div><h3>{title}</h3><p>{text}</p></div><ArrowUpRight className="step-arrow" size={18} /></div>)}</div>
        </div>
      </section>

      <section className="horien-section" id="horien">
        <div className="container horien-grid">
          <div className="horien-mark"><span>H</span><i>HORIEN</i><small>SEE THE DIFFERENCE</small></div>
          <div className="horien-copy"><div className="eyebrow light"><span /> OUR BRAND</div><h2>Meet Horien.</h2><p>Explore the Horien brand and its contact lens and lens-care product portfolio. For branded product availability and distribution opportunities, contact our team.</p><a className="button button-white" href="#contact" onClick={() => setForm({ ...form, product: 'Horien branded products' })}>Ask about Horien <ArrowRight size={17} /></a></div>
          <div className="horien-orb orb-one" /><div className="horien-orb orb-two" />
        </div>
      </section>

      <section className="section faq-section">
        <div className="container faq-layout">
          <div className="section-heading"><div className="eyebrow"><span /> COMMON QUESTIONS</div><h2>Before we<br /><em>get started.</em></h2><p className="lead">Have a question about sourcing, private label, or product documentation? Start here, or send us your specific requirements.</p></div>
          <div className="faq-list">
            {[
              ['Can Haichang support OEM or private-label projects?', 'We invite brand owners and distributors to discuss product selection, packaging, target markets, and project feasibility with our team. Available options and minimum quantities depend on the product and project.'],
              ['What products can I inquire about?', 'You can contact us about clear contact lenses, colored contact lenses, multipurpose lens-care solutions, and other currently supported products. We will confirm product availability and specifications for your requirements.'],
              ['Can you provide regulatory documents?', 'Available documents depend on the product, destination market, and applicable regulatory requirements. Please share your target country and product details so the team can confirm what is available.'],
              ['How do I request a quotation?', 'Use the inquiry form below and include your company, country, products of interest, estimated quantity, and any key requirements. The sales team can then review your request.']
            ].map(([q, a], i) => <div className={activeFaq === i ? 'faq-item faq-active' : 'faq-item'} key={q}><button onClick={() => setActiveFaq(activeFaq === i ? -1 : i)} aria-expanded={activeFaq === i}><span>{q}</span><ChevronDown size={19} /></button>{activeFaq === i && <p>{a}</p>}</div>)}
          </div>
        </div>
      </section>

      <section className="contact-section" id="contact">
        <div className="container contact-grid">
          <div className="contact-copy">
            <div className="eyebrow light"><span /> LET’S TALK BUSINESS</div>
            <h2>Tell us what<br /><em>you’re looking for.</em></h2>
            <p>Share a few details about your business and product requirements. We’ll have a clearer starting point for the conversation.</p>
            <div className="contact-details">
              <div><MapPin size={19} /><span><strong>Haichang</strong><small>Danyang, Jiangsu, China</small></span></div>
              <div><Mail size={19} /><span><strong>International sales</strong><small>Use the inquiry form to start a conversation</small></span></div>
            </div>
            <div className="contact-disclaimer">Please confirm current company contact details before publishing this website.</div>
          </div>
          <div className="form-card">
            {!submitted ? <form onSubmit={submitForm}>
              <div className="form-heading"><span>BUSINESS INQUIRY</span><h3>Request information</h3><p>Fields marked * are required.</p></div>
              <div className="form-row">
                <label>Full name *<input name="name" value={form.name} onChange={update} required placeholder="Your name" /></label>
                <label>Company *<input name="company" value={form.company} onChange={update} required placeholder="Company name" /></label>
              </div>
              <div className="form-row">
                <label>Business email *<input name="email" value={form.email} onChange={update} type="email" required placeholder="you@company.com" /></label>
                <label>Country / region *<input name="country" value={form.country} onChange={update} required placeholder="Your market" /></label>
              </div>
              <div className="form-row">
                <label>Product interest *<select name="product" value={form.product} onChange={update} required><option>OEM / Private Label</option><option>Clear Contact Lenses</option><option>Colored Contact Lenses</option><option>Lens-Care Solutions</option><option>Horien branded products</option><option>Other</option></select></label>
                <label>Estimated quantity<input name="quantity" value={form.quantity} onChange={update} placeholder="e.g. annual volume or MOQ" /></label>
              </div>
              <label>Tell us about your requirements *<textarea name="message" value={form.message} onChange={update} required rows="4" placeholder="Products, specifications, packaging, target market..." /></label>
              <button className="button button-primary submit-button" type="submit">Prepare inquiry <Send size={16} /></button>
              <p className="form-note">Prototype form only. It does not send or store your information until connected to a secure backend.</p>
            </form> : <div className="form-success"><div className="success-icon"><CheckCircle2 size={32} /></div><h3>Your inquiry draft is ready.</h3><p>This demonstration form has not sent your information. Connect a secure backend or business email service before launch.</p><button className="button button-primary" onClick={() => { setSubmitted(false); }}>Edit inquiry <ArrowRight size={16} /></button></div>}
          </div>
        </div>
      </section>
    </main>

    <footer className="footer">
      <div className="container">
        <div className="footer-main"><div><Logo /><p className="footer-blurb">Contact lens manufacturing and business partnerships for international markets.</p></div><div className="footer-links"><strong>Explore</strong><a href="#about">About Haichang</a><a href="#products">Products</a><a href="#oem">OEM & Private Label</a><a href="#quality">Quality & Compliance</a></div><div className="footer-links"><strong>Connect</strong><a href="#horien">Horien brand</a><a href="#contact">Business inquiries</a><a href="#contact">Request a quote</a></div><div className="footer-cta"><span>Have a project in mind?</span><a className="text-link" href="#contact">Let’s talk <ArrowUpRight size={17} /></a></div></div>
        <div className="footer-bottom"><span>© {new Date().getFullYear()} Haichang. Website concept for review.</span><span>Product availability and company claims should be verified before publication.</span><a href="#home">Back to top ↑</a></div>
      </div>
    </footer>
  </div>;
}

export default App;