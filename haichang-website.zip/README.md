# Haichang International Website

A responsive React + Vite website concept for Haichang's international manufacturing and OEM/private-label business.

## Requirements

- Node.js 22 or newer (a current LTS release is recommended)
- npm

## Run locally on Windows

1. Install Node.js from https://nodejs.org/
2. Extract this project folder.
3. Open Command Prompt in the extracted folder.
4. Run:

```bat
npm install
npm run dev
```

5. Open the local URL printed in the terminal (usually http://localhost:5173).

## Production build

```bat
npm run build
npm run preview
```

The generated production files will be in `dist/`.

## Important before publishing

- This is a frontend prototype. The inquiry form currently validates fields and shows a demo confirmation; it does not send or store submissions.
- Connect the form to a secure backend or approved business email service before production.
- Verify company name, address, contact details, certifications, product availability, specifications, and all marketing claims.
- Replace stock imagery with approved Haichang factory, product, packaging, and team photos.
- Verify usage rights and image licensing before launch.
- Configure your domain, hosting, analytics, privacy notice, and applicable cookie/data-protection requirements.
- Do not commit API keys, email credentials, or privileged Firebase credentials to the repository.

## Stack

- React
- Vite
- Lucide React icons
- CSS with responsive breakpoints

## Main files

- `src/App.jsx` — page content and interactive UI
- `src/styles.css` — visual design and responsive styles
- `index.html` — document metadata
